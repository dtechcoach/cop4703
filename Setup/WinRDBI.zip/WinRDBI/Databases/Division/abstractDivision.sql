%
% Understanding Relational Database Query Languages, S. W. Dietrich, Prentice Hall, 2001.
%
%---------------------------------------------------------------------------------------------------------------------------
%	SQL
%---------------------------------------------------------------------------------------------------------------------------
%    Abstract Division Example
%    Schema: abTable(a,b) and  bTable(b)
%    Query: Find the a's that are related to all of the b's in the bTable
%---------------------------------------------------------------------------------------------------------------------------

existentialDivision :=
   select    distinct T.a  
   from      abTable T   
   where    not exists  
      (select    * 	    				
       from      bTable B   
       where     not exists 	  
                 (select    * 			
                  from      abTable AB   
                  where     AB.a=T.a and AB.b=B.b));
