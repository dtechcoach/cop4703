%  Query 14A (page 137, 228 of the text book) is supported by winRDBI
%
%  BETWEEN operator is replaced by two boolean conditions in this query.
%
%  Retrieve all employees in department 5 whose salary is between $30,000 and $40,000.
%
%  The result must be
% 'John'	'B'	'Smith'	'123456789'	'1965-01-09'	'731 Fondren, Houston, TX'	'M'	30000	'333445555'	5
% 'Franklin''T'	'Wong'	'333445555'	'1955-12-08'	'638 Voss, Houston, TX'	'M'	40000	'888665555'	5
% 'Ramesh'	'K'	'Narayan'	'666884444'	'1962-09-15'	'975 Fire Oak, Humble, TX'	'M'	38000	'333445555'	5
%

q14A := 
  select *
  from employee
  where (eSalary >= 30000) and (eSalary <= 40000) and dNumber = 5 ;


