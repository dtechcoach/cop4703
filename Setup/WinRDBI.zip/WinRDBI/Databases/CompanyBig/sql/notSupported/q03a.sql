%  Query 3A (page 172, 235 of the text book) is NOT supported by winRDBI
%  since EXCEPT is not implemented on winRDBI
%
%  Retrieve the name of each employee who works on all projects
%  controlled by department number 4.
%
%  The result must be
%	Alicia  Zelaya
%	Ahmad   Jabbar
%

q3A := 
select	e.fName, e.lName
from	employee e
where	not exists
	((select	pNumber
	  from		projects
	  where		dNumber = 4)
	 except
	 (select	pNumber
	  from		worksOn w
	  where		w.eSSN = e.eSSN) );

