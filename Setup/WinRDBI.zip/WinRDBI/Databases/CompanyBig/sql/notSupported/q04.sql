%  Query 4 (page 137, 225 of the text book) is NOT supported by winRDBI
%  since UNION is not implemented on winRDBI
%
%  Make a list of project numbers that involve an employee whose last name is 'Wong',
%  either as a worker or as manager of the controlling department for the project.
%
%  The result must be
%	1
%	2
%	3
%	10
%	20
%
%

q4 := 
   (select distinct pNumber
    from projects, department d, employee e
    where e.dNumber = d.dNumber and mgrSSN = eSSN and lName = 'Wong'
   )
   union
   (select distinct p.pNumber
    from projects p, worksOn w, employee e
    where p.pNumber = w.pNumber and w.eSSN = e.eSSN and lName = 'Wong' )
   )
;
