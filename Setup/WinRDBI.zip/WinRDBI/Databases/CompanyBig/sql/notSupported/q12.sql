%  Query 12 (page 137, 227 of the text book) is NOT supported by winRDBI
%  since LIKE is not implemented on winRDBI
%
%  Retrieve the salary of every employee.
%

q12 := 
  select fName, lName
  from employee
  where eAddress like '%Houston, TX%' ;
