%  Query 14 (page 137, 228 of the text book) is NOT supported by winRDBI
%  since BETWEEN operator is not implemented on winRDBI
%
%  Retrieve all employees in department 5 whose salary is between $30,000 and $40,000.
%
%  The result must be
%	'Joyce'	'English'	27500
%	'John'	'Smith'	33000
%

q14 := 
  select *
  from employee
  where (eSalary between 30000 and 40000) and dNumber = 5 ;


