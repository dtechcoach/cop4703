%  Query 12A (page 137, 227 of the text book) is NOT supported by winRDBI
%  since LIKE is not implemented on winRDBI
%
%  Retrieve the salary of every employee.
%

q12A := 
  select fName, lName
  from employee
  where eBdate like '__5_______' ;
