%  Query 3 (page 172, 233 of the text book) is NOT supported by winRDBI
%  since CONTAINS is not implemented on winRDBI
%  See q3b.sql for another rephrasement of this query.
%
%  Retrieve the name of each employee who works on all projects
%  controlled by department number 4.
%
%  The result must be
%	Alicia  Zelaya
%	Ahmad   Jabbar
%

q3 := 
select	fName, lName
from	employee e
where	((select	pNumber
	  from		worksOn w
	  where		w.eSSN = e.eSSN)
	 contains
	 (select	pNumber
	  from		projects p
	  where		p.dNumber = 4))
;