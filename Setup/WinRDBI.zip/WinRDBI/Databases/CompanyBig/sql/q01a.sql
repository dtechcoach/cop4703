%  Query 1A (page 137,171,222 of the text book) 
%
%  Retrieve the name and address of all employees
%  who work for the 'Research' department.
%
%  The result must be
%	'John'	'Smith'	'731 Fondren, Houston, TX'
%	'Franklin'	'Wong'	'638 Voss, Houston, TX'
%	'Ramesh'	'Narayan'	'975 Fire Oak, Humble, TX'
%	'Joyce'	'English'	'5631 Rice, Houston, TX'
%

q1A := 
select fName, lName, eAddress
from	employee, department
where	department.dName = 'Research' and department.dNumber = employee.dNumber;
