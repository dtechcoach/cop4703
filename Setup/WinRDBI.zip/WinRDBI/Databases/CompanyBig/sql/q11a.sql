%  Query 11A (page 137, 225 of the text book) is supported by winRDBI
%
%  Retrieve all distinct salary values of employees.
%
%  The result must be
%	30000
%	40000
%	25000
%	43000
%	38000
%	55000
%

q11A := 
  select distinct eSalary
  from employee ;
