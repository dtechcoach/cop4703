%  Query 2 (page 137, 220 of the text book) is supported by winRDBI
%
%  For every project located in 'Stafford',list the project number, the controlling 
%  department number, and the department mangager's last name, address, and birth date.
%
%  The result must be
%	10	4	'Wallace'	'291 Berry, Bellaire, TX'	'1941-06-20'
%	30	4	'Wallace'	'291 Berry, Bellaire, TX'	'1941-06-20'
%
%

q2 := 
   select pNumber, p.dNumber, lName, eAddress, eBdate
   from projects p, department d, employee e
   where p.dNumber = d.dNumber and mgrSSN = eSSN and pLocation = 'Stafford' ;

