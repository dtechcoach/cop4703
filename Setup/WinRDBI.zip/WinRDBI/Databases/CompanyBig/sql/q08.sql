%  Query 8 (page 137, 222 of the text book) is supported by winRDBI
%
%  Aliasing as "from employee as e, employee as s" is NOT supported by winRDBI.
%  However, simple aliasing as "from employee e, employee s" is supported by winRDBI.
%
%  For each employee, retrieve the employee's first and last name and
%  the first and last name of his/her immediate supervisor.
%
%  The result must be
%	'John'	'Smith'	'Franklin'	'Wong'
%	'Franklin'	'Wong'	'James'	'Borg'
%	'Alicia'	'Zelaya'	'Jennifer'	'Wallace'
%	'Jennifer'	'Wallace'	'James'	'Borg'
%	'Ramesh'	'Narayan'	'Franklin'	'Wong'
%	'Joyce'	'English'	'Franklin'	'Wong'
%	'Ahmad'	'Jabbar'	'Jennifer'	'Wallace'
%

q8 := 
select e.fName, e.lName, s.fName, s.lName
from employee e, employee s
where e.superSSN = s.eSSN ;
