%  Query 15 (page 137, 228 of the text book) is supported by winRDBI
%
%  Retrieve a list of employees and the projects they are working on, ordered by
%  department and, within each department, ordered alphabetically by last name, first name.
%
%  The result must be 16 tuples:
% 'Administration'	'Jabbar'	'Ahmad'	'Newbenefits'
% 'Administration'	'Jabbar'	'Ahmad'	'Computerization'
% 'Administration'	'Wallace'	'Jennifer'	'Reorganization'
% 'Administration'	'Wallace'	'Jennifer'	'Newbenefits'
% 'Administration'	'Zelaya'	'Alicia'	'Computerization'
% 'Administration'	'Zelaya'	'Alicia'	'Newbenefits'
% 'Headquarters'	'Borg'	'James'	'Reorganization'
% 'Research'	'English'	'Joyce'	'ProductY'
% 'Research'	'English'	'Joyce'	'ProductX'
% 'Research'	'Narayan'	'Ramesh'	'ProductZ'
% 'Research'	'Smith'	'John'	'ProductY'
% 'Research'	'Smith'	'John'	'ProductX'
% 'Research'	'Wong'	'Franklin'	'Reorganization'
% 'Research'	'Wong'	'Franklin'	'Computerization'
% 'Research'	'Wong'	'Franklin'	'ProductZ'
% 'Research'	'Wong'	'Franklin'	'ProductY'
%

q15 := 
  select dName, lName, fName, pName
  from department d, employee e, worksOn w, projects p
  where d.dNumber = e.dNumber and e.eSSN = w.eSSN and w.pNumber = p.pNumber
  order by dName, lName, fName ;


