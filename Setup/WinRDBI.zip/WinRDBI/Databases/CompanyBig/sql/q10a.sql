%  Query 10A (page 137, 223, 224 of the text book) is supported by winRDBI
%
%  Select all cobinations of employee eSSN and department dName.
%
%  The result must be
%	8_employees x 3_departments = 24 tuples
%

q10 := 
  select *
  from employee, department;
