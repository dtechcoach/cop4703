%  Query 1D (page 137,171,224 of the text book) 
%
%  Retrieve the name and address of all employees
%  who work for the 'Research' department.
%
%  The result must be
%    Four tuples Employee_Department values
%

q1D := 
select *
from	employee, department
where	dName = 'Research' and employee.dNumber = department.dNumber ;
