%  Query 9 (page 137, 223 of the text book) is supported by winRDBI
%
%  Select all employees SSNs.
%
%  The result must be
%	'123456789'
%	'333445555'
%	'999887777'
%	'987654321'
%	'666884444'
%	'453453453'
%	'987987987'
%	'888665555'
%

q9 := 
  select eSSN
  from employee;
