%  Query 3B (page 137, 172, 235 of the text book) is supported by winRDBI
%
%  Retrieve the name of each employee who works on all projects
%  controlled by department number 4.
%
%  The result must be
%	Alicia  Zelaya
%	Ahmad   Jabbar
%

q3B := 
select	e.fName, e.lName
from	employee e
where	not exists
	(select	 *
	 from	 worksOn b
	 where	 (b.pNumber in  (select pNumber
			     from   projects
			     where  dNumber = 4))
		and
		not exists  (select *
			     from   worksOn c
			     where  c.eSSN = e.eSSN
			       and  c.pNumber = b.pNumber));
