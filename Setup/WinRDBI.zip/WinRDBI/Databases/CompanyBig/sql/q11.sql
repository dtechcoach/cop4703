%  Query 11 (page 137, 225 of the text book) is supported by winRDBI
%
%  Retrieve the salary of every employee.
%
%  The result must be
%	30000
%	40000
%	25000
%	43000
%	38000
%	25000
%	25000
%	55000
%

q11 := 
  select all eSalary
  from employee ;
