%  Query 13 (page 137, 227 of the text book) is supported by winRDBI
%
%  Show the resulting salaries if every employee working on the 'ProductX' project is
%  given a 10 percent raise.
%
%  The result must be
%	'Joyce'	'English'	27500
%	'John'	'Smith'	33000
%

q13 := 
  select fName, lName, (1.1 * eSalary) as increasedSalary
  from employee e, worksOn w, projects p
  where e.eSSN = w.eSSN and w.pNumber = p.pNumber and pName = 'ProductX' ;


