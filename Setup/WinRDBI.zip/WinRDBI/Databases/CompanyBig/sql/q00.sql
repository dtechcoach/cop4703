%  Query 0 (page 137, 219 of the text book) is supported by winRDBI
%
%  Retrieve the birthdate and address of the employee whose name is 'John B Smith'.
%
%  The result must be
%	'1965-01-09'	'731 Fondren, Houston, TX'
%
%

q0 := 
   select eBdate, eAddress
   from employee
   where fName = 'John' and mInit = 'B' and lName = 'Smith' ;

