%  Query 1 (page 137, 220 of the text book) is supported by winRDBI
%
%  Retrieve the name and address of all employees who work for the 'Research' department.
%
%  The result must be
%	'John'	'Smith'	'731 Fondren, Houston, TX'
%	'Franklin'	'Wong'	'638 Voss, Houston, TX'
%	'Ramesh'	'Narayan'	'975 Fire Oak, Humble, TX'
%	'Joyce'	'English'	'5631 Rice, Houston, TX'
%
%

q1 := 
   select fName, lName, eAddress
   from employee e, department d
   where dName = 'Research' and d.dNumber = e.dNumber ;

