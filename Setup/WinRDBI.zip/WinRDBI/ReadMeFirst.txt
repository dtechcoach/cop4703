WinRDBI Version 5.0.170_04  -- ReadMeFirst document

WinRDBI runs on Windows computers (supports both 32-bit and 64-bit systems) 
This software is not linked to Windows Registry
and it can be removed by simply deleting this directory.
For Linux users, install WinRDBI Version 3.1 and configure it as needed.

Before starting WinRDBI, make sure that you have installed java (1.7 or later version) 
and find the the path for java executables.
Depending on the installed Java feature (32bit or 64bit),
edit either .\64bit\64_winRDBI.bat or .\32bit\32_winRDBI.bat using any text editor.
Subsequently, double click on this modified batch file to start WinRDBI.

I have created the WinRDBI schema for several databases and query files
   - WinRDBI database files: *.rdb
   - relational algebra query files: *.alg
   - relational tuple calculus query files: *.trc
   - relational domain calculus query files: *.drc
   - WinRDBI specific relational sql query files: *.sql
and customized them according to WinRDBI syntax (see RelAlgSyntax.doc).

To test these queries, 
 - start WinRDBI
 - to open a database
   click "open" yellow folder icon
   pull down menu  Look In: box and browse to the folder ..\Databases\PremiereProducts
   select Premiere.rdb
   click Open
   Now click on any table on the left panel to see the contents of the table

 - to test a specific query,
   make sure the database for the query is already opened in a WinRDBI window
   click "open" yellow folder icon 
   select the desired query
   click Open
   A query window appears (upper part contain query and the lower part for results)
   click inside the upper part of the query winodw
   click "!" icon on the top panel of buttons to run the query
   click any relation on the left lower part of the query window to see the contents
   click the last bottom relation to see the final result of the query
   Use horizontal & vertical sliders to view the complete query/result

Explore all relational algebra operations and understand them.

Try all these queries and then solve Relational Algebra and Calculus questions for the Asg1.

For additional help, visit http://winrdbi.asu.edu

--Prabakar
5/4/2014
