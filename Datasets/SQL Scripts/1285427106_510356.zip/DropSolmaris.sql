DROP TABLE Location;

DROP TABLE CondoUnit;

DROP TABLE Owner;

DROP TABLE ServiceCategory;

DROP TABLE ServiceRequest;