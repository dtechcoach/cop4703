DROP TABLE Rep;

DROP TABLE Customer;

DROP TABLE Orders;

DROP TABLE Item;

DROP TABLE OrderLine;
