DROP TABLE Customer;

DROP TABLE Trip;

DROP TABLE Guide;

DROP TABLE Reservation;

DROP TABLE TripGuides;
